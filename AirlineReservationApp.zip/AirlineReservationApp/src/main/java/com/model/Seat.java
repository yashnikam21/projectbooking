package com.model;


public class Seat {
	private String chkbx;

	public String getChkbx() {
		return chkbx;
	}

	public void setChkbx(String chkbx) {
		this.chkbx = chkbx;
	}

	public Seat(String chkbx) {
		super();
		this.chkbx = chkbx;
	}
	public Seat()
	{
		super();
	}
}
